*PADS-LIBRARY-PART-TYPES-V9*

NE555PWR SOP65P640X120-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.03.09.13.09.32
"Mouser Part Number" 595-NE555PWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/NE555PWR?qs=rLYyFdxB%2FmrUWQU7cliZgA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" NE555PWR
"Description" Single Precision Timer
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-SFU2/DSASFU100031259.pdf
"Geometry.Height" 1.2mm
GATE 1 8 0
NE555PWR
1 0 G GND
2 0 U TRIG
3 0 S OUT
4 0 U RESET
8 0 P VCC
7 0 U DISCH
6 0 U THRES
5 0 U CONT

*END*
*REMARK* SamacSys ECAD Model
228748/1911306/2.50/8/3/Integrated Circuit
